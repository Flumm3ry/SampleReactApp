export default interface CarDetails {
    id: number,
    carMake: string,
    carModel: string,
    year: number,
    color: string,
    emailAddress: string,
}