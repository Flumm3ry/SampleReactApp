export default interface CarDetails {
    id: number,
    car_make: string,
    car_model: string,
    year: number,
    color: string,
    email_address: string,
}